package com.walmart.services.lmde.domain;

import java.io.Serializable;
import java.util.List;

public class ElasticSearchOrderModel implements Serializable {
    private String orderId;
    private List<AuditModel> audits;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public List<AuditModel> getAudits() {
        return audits;
    }

    public void setAudits(List<AuditModel> audits) {
        this.audits = audits;
    }
}
