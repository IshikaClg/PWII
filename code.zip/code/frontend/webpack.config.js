//
// To get Electrode to load this webpack.config.js file, set the env USE_APP_WEBPACK_CONFIG to true.
// See it being set in xclap.js for this sample.
//

const path = require('path');

const { initWebpackConfigComposer, compose, options } = require('@xarc/app-dev/config/webpack');

//
// options contains information pertain to Electrode's internal webpack
// partials and profiles, so in order to get those, it should be passed
// to initWebpackConfigComposer.
//
const { composer, ...opts } = initWebpackConfigComposer(options);
//
// compose function runs the composer.compose method with some house keeping
// logic that pertains to Electrode's internal webpack config partials, such
// as removing the custom _name field to identify webpack plugins.
//

const finalConfig = compose({ composer, ...opts });
finalConfig.resolve = {
  ...finalConfig.resolve,
  alias: {
    '@client': path.resolve(__dirname, 'src/client/'),
    '@nextui': path.resolve(__dirname, 'src/nextui/')
  }
};

// Unncomment this code to run the package analyzer
// const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;
// finalConfig.plugins.push(new BundleAnalyzerPlugin());

module.exports = finalConfig;
