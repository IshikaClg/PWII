/* @jsx createElement */
import { tokenHandler } from '@xarc/index-page';
import { createElement, IndexPage, RegisterTokenIds, Require, Token } from 'subapp-server/template';
import { ReserveSpot } from 'subapp-web';

const Template = (props) => (
  <IndexPage DOCTYPE="html">
    <RegisterTokenIds handler={tokenHandler} />
    <Token _id="INITIALIZE" />
    <html lang="en">
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="icon" type="image/png" href="https://www.walmart.com/favicon.ico" />
        <ReserveSpot saveId="headEntries" />
        <Token _id="META_TAGS" />
        <Token _id="PAGE_TITLE" />
        <Require _id="subapp-web/lib/init" />
        <Token _id="UI_CONFIG" />
        <Token _id="CRITICAL_CSS" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
      </head>
      <Token _id="HEAD_CLOSED" />
      <body>
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
        <noscript>
          <h4>JavaScript is Disabled</h4>
          <p>Please enable JavaScript in your browser and reload the page.</p>
        </noscript>
        {props.children}
        <Require _id="subapp-web/lib/start" />
      </body>
      <Token _id="BODY_CLOSED" />
    </html>
    <Token _id="HTML_CLOSED" />
  </IndexPage>
);

export default Template;
