import React from "react";
import { loadSubApp } from "subapp-react";
import Main from "./app";

const App = () => {
  return( <Main />);
};

export default loadSubApp({ Component: App, name: "ordervisibility" });
