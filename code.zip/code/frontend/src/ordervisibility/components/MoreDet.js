// import React from 'react'
// import { Link, useParams } from 'react-router-dom'


// //export default function MoreDet({ match, location }) {
//   const MoreDet = ({ match, location }) =>{
//     const { params: { timestamp } } = match;
//     return (
//       <>
//         <p>
//           <strong>User ID: </strong>
//           {timestamp}
//         </p>
//       </>
//     );
//   }
//   // return (
//     <div>
//       <p><strong>{location.moreDet}</strong></p>
//       <>
//       <h1 className={`text-center my-5 text-${props.mode==='light'?'dark' : 'light'}`}>Order Visibility Dashboard</h1>
//       <table className="table table-bordered table-hover my-2">
//             <thead>
//               <tr>
//                 <th scope="col" style={{color :`${props.mode==='light'?'black':'white'}`}}>Action</th>
//                 <th scope="col" style={{color :`${props.mode==='light'?'black':'white'}`}}>Event</th>
//                 <th scope="col" style={{color :`${props.mode==='light'?'black':'white'}`}}>TimeStamp</th>
//                 <th scope="col" style={{color :`${props.mode==='light'?'black':'white'}`}}>Status</th>
//                 <th scope="col" style={{color :`${props.mode==='light'?'black':'white'}`}}>Initiator</th>
//               </tr>
//             </thead>
//             <tbody>
//               <tr>
//                   <th scope="row" style={{color :`${props.mode==='light'?'black':'white'}`}}></th>
//                   <td style={{color :`${props.mode==='light'?'black':'white'}`}}></td>
//                   <td style={{color :`${props.mode==='light'?'black':'white'}`}}></td>
//                   <td style={{color :`${props.mode==='light'?'black':'white'}`}}></td>
//                   <td style={{color :`${props.mode==='light'?'black':'white'}`}}></td>
//               </tr> 
//             </tbody>
//       </table>
//       <div className='d-flex justify-content-center my-4'>
//       <Link to="/" type="button" className="btn btn-danger btn-lg">Close</Link>
//       </div>
//       </>
//     </div>
//   // )
// //}



