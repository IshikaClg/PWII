import React, { useState } from 'react'
import { BrowserRouter, Link } from 'react-router-dom'


function OrderDetail({mode,taskSet,dtaskId}) {
  return (
    <div>
      <>
            <table className="table table-bordered table-hover my-2">
            <thead>
              <tr>
                <th scope="col" style={{color :`${mode==='light'?'black':'white'}`}}>Event</th>
                <th scope="col" style={{color :`${mode==='light'?'black':'white'}`}}>TimeStamp</th>
                <th scope="col" style={{color :`${mode==='light'?'black':'white'}`}}>Status</th>
                <th scope="col" style={{color :`${mode==='light'?'black':'white'}`}}>More Details</th>
              </tr>
            </thead>
            <tbody>
                 { taskSet[Object.keys(taskSet)[dtaskId]].map((element) =>{
                   return (
                     <>
                     <tr>
                    <th scope="row" style={{color :`${mode==='light'?'black':'white'}`}}>{element.action}</th>
                    <td style={{color :`${mode==='light'?'black':'white'}`}}>{element.timestamp}</td>
                 <td style={{color :`${element.status==='INITIATED'?'blue':element.status==='SUCCESS'?'green':'red'}`}}>{element.status}</td>
                  <td><Link to={`/moreDet/${element.action}/${element.event}/${element.timestamp}/${element.status}/${element.initiator}`} className={`btn btn-${mode==='light'?'dark':'light'} btn-sm`} mode={mode}>MORE DETAILS</Link></td> 
                  </tr>
                  </>
                    )
                  })}
              
              </tbody>
            </table>
      </>
    </div>
  )
}

export default OrderDetail
