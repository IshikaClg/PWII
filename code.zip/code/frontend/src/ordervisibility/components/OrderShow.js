import Axios from 'axios';
import React, { useState } from 'react'
import OrderDetail from '../components/OrderDetail'
    
export default function OrderShow(props) {
    
    const [taskSet, setTaskSet] = useState({})
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(2);
    const [totalResults, setTotalResults] = useState(0);
    const [dtaskId,setDTaskId]= useState(0);
    const [noData, setNoData] = useState(1)

    
    const handlePrevClick =()=>{
        setDTaskId(dtaskId-1);
        setPage(page - 1);
        setPageSize(pageSize-1);
    }
    
    const handleNextClick =()=>{
         if(page + 1 > totalResults-1){

         }
        else{
        setDTaskId(dtaskId+1);
        setPage(page + 1);
        setPageSize(pageSize+1);
        }
    }
    
    const getData =(tasks) =>{
        const data = tasks.reduce((acc, task, index) => {
            if(acc[task.taskId]){
                acc[task.taskId].push(task);
            }else{
                acc[task.taskId] = [task];
            }
            return acc
        }, {}) 
        setTotalResults(Object.keys(data).length)
        return data
    }
    
    const displayMethod =() =>{
        return <div className='row' style={{display :'inline'}}>
            <OrderDetail taskSet={taskSet} mode={props.mode} dtaskId={dtaskId} />
          </div>
        }
    const displayMethod2 =() =>{
                return <div className='row' style={{display :'inline'}}>
                <OrderDetail mode={props.mode} taskSet={taskSet} dtaskId={dtaskId + 1} />
              </div>
            
        }
        const insertData =()=>{
            const searchBtn = document.getElementById('searchBtn')
            searchBtn.addEventListener("click", function() {
                document.getElementById("toggleData").innerHTML = "";
              });
            Axios.get('http://localhost:8080/lmde-app/services/dispatcher/elasticviewdata?orderId='+`${document.getElementById('orderId').value}`).then((response) =>{  
            setNoData(Object.values(response.data)[1] === null ? 0 : 1)
            if(Object.values(response.data)[1] !==null )
                {
                    const ary =Object.values(response.data)[1]
                    setTaskSet(getData(ary))
                }  
            })    
        }
         const displayNotPresent=() =>{
            return <b><h1 style={{color: 'red', fontFamily: 'Brush Script MT' ,fontSize :'100px'}}><marquee direction = "left"><img src={require('./notexist.png')} style={{width:'100px', height :'100px'}}  /> Oops! Order Id Doesn't Exist</marquee></h1></b>
         }
         
   
  return (
       <div>
      <>
      <h1  className={`text-center my-5 text-${props.mode==='light'?'dark' : 'light'}`}>Order Visibility Dashboard</h1>
            <div className="input-group">
            <input type="number" className="form-control d-flex justify-content-center" style={{marginLeft : '300px'}} placeholder="Search On Order Id" aria-label="Search On Order Id " id='orderId'/>
            <div className="input-group-append">
                <button className="btn btn-outline-secondary btn-primary btn-lg d-flex justify-content-center" style={{color : 'white', marginRight :'400px'}} id='searchBtn' onClick={insertData}>Search</button>
            </div>
            </div>
            {noData === 0 && <div className='container d-flex justify-content-around my-5'>{displayNotPresent()}</div>}
      {
        Object.keys(taskSet).length>0 && <div className='container' id='toggleData'>
        <h1 className={`text-center my-3 text-${props.mode==='light'?'dark' : 'light'}`}>Order Description</h1>
        <div className='row my-2'>
            <div className='container d-flex justify-content-around' > 
                <div style={{flexDirection :'column'}}>
                <h2 className={`text-center text-${props.mode==='light'?'dark' : 'light'}`}>Task ID : {[Object.keys(taskSet)[dtaskId]]}</h2> 
                    {displayMethod()}      
                </div>
                <div style={{flexDirection :'column'}}>
                <h2 className={`text-center text-${props.mode==='light'?'dark' : 'light'}`}>Task ID : {[Object.keys(taskSet)[dtaskId+1]]}</h2>
                    {displayMethod2()} 
                </div>
            </div>   
        </div> 
      
        <div className='container d-flex justify-content-between my-3'>
            <button className={`btn btn-${props.mode==='light'?'dark':'light'} btn-lg`} disabled={page<=1} onClick={() => { handlePrevClick()}}>&larr; Previous</button>
            <button className={`btn btn-${props.mode==='light'?'dark':'light'} btn-lg`} disabled={page + 1 > totalResults-1} onClick={() => { handleNextClick()}}>Next &rarr;</button>
        </div>
      
      </div>
      }
      </>
      </div>
  )
}

