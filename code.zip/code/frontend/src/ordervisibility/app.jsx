import React, { useState } from 'react';
import {BrowserRouter, Route, Switch, Link } from 'react-router-dom';
import Headings from "./components/Headings";
import OrderShow from "./components/OrderShow";
import MoreDet from "./components/MoreDet";

export default function Main() {
    const [mode, setMode] = useState('light');
    const [text, setText] = useState('Enable Dark Mode')
    const settingMode = () =>{
        if(mode==='light'){
            setMode('dark')
            setText('Enable Light Mode')
            document.body.style.backgroundColor='#121212'
        }
        else{
            setMode('light')
            setText('Enable Dark Mode')
            document.body.style.backgroundColor='white'
        }
    }
    const MoreDet = ({ match, location }) =>{
        const { params: { action } } = match;
        const { params: { event } } = match;
        const { params: { timestamp } } = match;
        const { params: { status } } = match;
        const { params: { initiator } } = match;
        return (
            <div>
            <p><strong>{location.moreDet}</strong></p>
            <>
            <h1 className={`text-center my-5 text-${mode==='light'?'dark' : 'light'}`}>Order Visibility Dashboard</h1>
            <table className="table table-bordered table-hover my-2">
                  <thead>
                    <tr>
                      <th scope="col" style={{color :`${mode==='light'?'black':'white'}`}}>Action</th>
                      <th scope="col" style={{color :`${mode==='light'?'black':'white'}`}}>Event</th>
                      <th scope="col" style={{color :`${mode==='light'?'black':'white'}`}}>TimeStamp</th>
                      <th scope="col" style={{color :`${mode==='light'?'black':'white'}`}}>Status</th>
                      <th scope="col" style={{color :`${mode==='light'?'black':'white'}`}}>Initiator</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                        <th scope="row" style={{color :`${mode==='light'?'black':'white'}`}}>{action}</th>
                        <td style={{color :`${mode==='light'?'black':'white'}`}}>{event}</td>
                        <td style={{color :`${mode==='light'?'black':'white'}`}}>{timestamp}</td>
                        <td style={{color :`${mode==='light'?'black':'white'}`}}>{status}</td>
                        <td style={{color :`${mode==='light'?'black':'white'}`}}>{initiator}</td>
                    </tr> 
                  </tbody>
            </table>
            <div className='d-flex justify-content-center my-4'>
            <Link to="/" type="button" className="btn btn-danger btn-lg">Close</Link>
            </div>
            </>
          </div>
        );
      }
    return(
        <>
        <Headings mode = {mode} settingMode = {settingMode} text = {text} />
        
        <BrowserRouter>
            <Switch>
                <Route path="/moreDet/:action/:event/:timestamp/:status/:initiator" component= {MoreDet}>
                </Route>
                <Route path="/">
                <OrderShow mode={mode}/>
                </Route>
             </Switch>
        </BrowserRouter>
        </>
    );
}