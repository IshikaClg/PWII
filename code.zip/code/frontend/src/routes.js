const Path = require('path');

const subAppOptions = {serverSideRendering: false};

const tokenHandlers = [Path.join(__dirname, './token-handler')];

export default {

    '/ordervisibility/': {
        pageTitle: 'Order Visibility UI',
        subApps: [['./ordervisibility', subAppOptions]],
        templateFile: './templates/ordervisibility',
        tokenHandlers

    }
};