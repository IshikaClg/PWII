"use strict";

if (process.env.MARKET_NAME) {
    process.env.ONEOPS_ENVPROFILE = process.env.ONEOPS_ENVPROFILE + '-' + process.env.MARKET_NAME
    process.env.ONEOPS_ENVIRONMENT = process.env.ONEOPS_ENVIRONMENT + '-' + process.env.MARKET_NAME
    process.env.NODE_ENV = process.env.NODE_ENV + '-' + process.env.MARKET_NAME
  }

//require("@walmart/electrode-wml-app")();
/* eslint-disable global-require */

// process.on("SIGINT", () => {
//   process.exit(0);
// });

// const electrodeConfippet = require("electrode-confippet");
// const support = require("electrode-archetype-react-app/support");

// //
// const staticPathsDecor = require("electrode-static-paths");
// const electrodeServer = require("electrode-server");

// //
// // sample to show electrode server startup events
// // https://github.com/electrode-io/electrode-server#listener-function
// //
// function setupElectrodeServerEvents(emitter) {
//   emitter.on("config-composed", (data, next) => next());
//   emitter.on("server-created", (data, next) => next());
//   emitter.on("connections-set", (data, next) => next());
//   emitter.on("plugins-sorted", (data, next) => next());
//   emitter.on("plugins-registered", (data, next) => next());
//   emitter.on("server-started", (data, next) => next());
//   emitter.on("complete", (data, next) => next());
// }
// //

// const startServer = config => {
//   //
//   const decor = staticPathsDecor();
//   if (!config.listener) config.listener = setupElectrodeServerEvents;
//   return electrodeServer(config, [decor]);
//   //
// };

// module.exports = () =>
//   support.load().then(() => {
//     const config = electrodeConfippet.config;
//     return startServer(config);
//   });

// if (require.main === module) {
//   module.exports();
// }

"use strict";

const support = require("@xarc/app/support");
const electrodeServer = require("@walmart/electrode-wml-server");
const electrodeConfig = require("@walmart/electrode-config");
const fyi = require("@walmart/electrode-fyi");


async function startServer(supportConfig, appConfig) {
  supportConfig = supportConfig || {};
  try {
    await support.load(supportConfig);

    let config = appConfig || electrodeConfig.config;

    return electrodeServer(config);
  } catch (err) {
    fyi.error("Starting App Server failed", err.stack);
    throw err;
  }
};
startServer();
